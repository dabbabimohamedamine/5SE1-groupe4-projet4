package tn.esprit.devops_project.entities;

public enum SupplierCategory {
ORDINAIRE,CONVENTIONNE
}
